package Principal;

//interfazz de metodo abstracto

public interface Figura {
    void dibujar();
}
